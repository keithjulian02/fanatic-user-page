import React, { useState } from "react";
// Sections
import TopNavbar from "../components/Nav/TopNavbar";
import Footer from "../components/Sections/Footer";
import "antd/dist/reset.css";
import { Avatar, Typography, Input, Button, Modal } from 'antd';
import { AntDesignOutlined, MailOutlined, BorderlessTableOutlined, CalendarOutlined, EyeTwoTone, EyeInvisibleOutlined} from '@ant-design/icons';
import "../style/profile.css";
import EditableTable from "../components/Sections/EditableTable"

export default function Profile() {
    const {Title} = Typography;
    const [isEditingEmail, setIsEditingEmail] = useState(false);
    const [editingCustomerEmail, setEditingCustomerEmail] = useState(null);
    const [customer, setCustomer] = useState({
        id: "1", 
        firstname: "Keith", 
        lastName: "Julian", 
        email: "keithjulian@gmail.com",
        password: "blackberrii",
        creationdate: "2022-02-23", 
        subscriptiontype: "Basic",
        subscriptionpurchse: "2022-02-24",
        subscriptionexpiry: "2022-03-25",
        subscriptionkey: "ADGHK-ADSKG-ASH13-AETOU-WEITY"});
    
    
    const onEditEmailRecord = (record) => {
            setIsEditingEmail(true);
            setEditingCustomerEmail({ ...record });
          }; 

    const resetEditingEmail = () => {
            setIsEditingEmail(false);
            setEditingCustomerEmail(null);
          };
    return (
        <>
            <TopNavbar />
            <div className="main_cont" >
              <div className="userProfileHeader" style={{ marginTop: "100px" }}>
                <Title className="title">User Profile</Title>
                <Avatar className="avatar"
                    size={{ xs: 48, sm: 64, md: 80, lg: 128, xl: 150, xxl: 300 }}
                    icon={<AntDesignOutlined />}
                />
                <br/><br/>    
                <Title level={3}>Hello {customer.firstname} {customer.lastName}!</Title>  
             </div>

            <div className="userProfileDetails">
                <Button type="text" readOnly="true">Email: </Button>
                <Input className="inputButtonEmail" size="large" value={customer.email} prefix={<MailOutlined />} readOnly="true"/>
                <Button className="editButtons" type="primary" onClick={() => {
                onEditEmailRecord();
              }}>Edit Email</Button> 
                <br/><br/>
                <Button type="text" readOnly="true">Account ID: </Button>
                <Input className="inputButtonID" size="large" value={customer.id} prefix={<BorderlessTableOutlined />} readOnly="true" />
                <br/><br/>
                <Button type="text" readOnly="true">Creation Date: </Button>
                <Input className="inputButtonAccountDate" size="large" value={customer.creationdate} prefix={<CalendarOutlined />} readOnly="true" />
                <br/><br/>
                <Button type="text" readOnly="true">Password </Button>
                <Input.Password className="inputButtonPassword" readOnly="true" value={customer.password} iconRender={(visible) => (visible ? <EyeTwoTone /> : <EyeInvisibleOutlined />)}/>
                <Button className="editButtons" type="primary">Change Password</Button> 
                <br/><br/>
            </div>
     
            <Modal
          title="Edit Customer Email"
          open={isEditingEmail}
          okText="Save"
          onCancel={() => {
            resetEditingEmail();
          }}
          
        >
        <b>Old Email: {customer.email} </b> <Input
        value={customer.email}
        readOnly="true"
        />    
            <b>New Email: </b> <Input
        value={customer.email}
        onChange={(e) => {
          setCustomer((customer) => {
            return { ...customer, email: e.target.value };
          });
        }}
      />
        </Modal>
            
            
    </div>
            <div className="Subscription">
            <Title className="title">Your Subscription</Title>
            </div>
            <div className="ticketTable">
            <Title className="title">Your Tickets</Title>
            <EditableTable />
            </div>
            <Footer />
        </>
    );
}


